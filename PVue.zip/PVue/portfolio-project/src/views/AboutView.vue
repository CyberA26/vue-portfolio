<template>
  <div class="about">
    <h1>About Me</h1>
    <p>I'm a Vue.js developer passionate about building clean UIs.</p>
  </div>
</template>

<script>
export default {
  name: 'AboutView'
}
</script>

<style>
.about {
  padding: 20px;
}
</style>