<template>
  <div class="home">
  <h1>Welcome to My Portfolio</h1>
  <p>This is the homepage of my Vue.js project.</p>
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  }
</script>

<style scoped>
.home {
  padding: 20px;
}
</style>